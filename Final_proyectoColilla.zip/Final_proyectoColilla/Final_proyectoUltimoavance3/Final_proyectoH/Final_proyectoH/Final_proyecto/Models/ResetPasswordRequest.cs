﻿namespace Final_proyecto.Models
{
    public class ResetPasswordRequest
    {
        public string Email { get; set; }
        public string NewPassword { get; set; }
        public string CodigoVerificacion { get; set; }
    }
}

