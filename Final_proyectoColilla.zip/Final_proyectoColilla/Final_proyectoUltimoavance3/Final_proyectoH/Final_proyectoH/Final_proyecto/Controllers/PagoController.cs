﻿using Microsoft.AspNetCore.Mvc;
using Final_proyecto.Data;
using Final_proyecto.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace Final_proyecto.Controllers
{
    public class PagoController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PagoController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(int id)
        {
            var coche = await _context.Coches.FindAsync(id);
            if (coche == null)
            {
                return NotFound();
            }
            return View(coche);
        }
    }
}
