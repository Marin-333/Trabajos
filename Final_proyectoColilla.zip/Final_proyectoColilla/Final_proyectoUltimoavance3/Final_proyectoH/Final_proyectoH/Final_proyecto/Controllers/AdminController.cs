﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Final_proyecto.Data;
using Final_proyecto.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace Final_proyecto.Controllers
{
    [Authorize(Roles = "Administrador")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var coches = await _context.Coches.ToListAsync();
            return View(coches);
        }

       /* public async Task<IActionResult> Edit(int id)
        {
            var coche = await _context.Coches.FindAsync(id);
            if (coche == null)
            {
                return NotFound();
            }
            return View(coche);
        }
        
       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Marca,Modelo,Precio,Año,Color,Npuertas,ImagenUrl,Stock")] Coches coche)

        {
            if (id != coche.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(coche);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CocheExists(coche.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(coche);
        }

        private bool CocheExists(int id)
        {
            return _context.Coches.Any(e => e.Id == id);
        }
        */
    }
}
