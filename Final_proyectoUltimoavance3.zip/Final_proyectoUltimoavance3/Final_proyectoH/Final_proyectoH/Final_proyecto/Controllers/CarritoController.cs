﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Final_proyecto.Data;
using Final_proyecto.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System;

namespace Final_proyecto.Controllers
{
    [Authorize]
    public class CarritoController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CarritoController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var carrito = await _context.CarroItems.Include(ci => ci.Cliente).ToListAsync();
            return View(carrito);
        }

        [HttpPost]
        public async Task<IActionResult> Agregar(int id, int clienteId, string marca, string modelo, decimal precio, string imagenUrl, int cantidad)
        {
            if (cantidad <= 0)
            {
                ModelState.AddModelError("", "La cantidad debe ser un valor positivo.");
                return RedirectToAction("Index");
            }

            try
            {
                var carroItems = new CarroItems
                {
                    Id = id,
                    ClienteId = clienteId,
                    Marca = marca,
                    Modelo = modelo,
                    Precio = precio,
                    ImagenUrl = imagenUrl,
                    Cantidad = cantidad
                };

                _context.CarroItems.Add(carroItems);
                await _context.SaveChangesAsync();

                TempData["Message"] = "El elemento se agregó al carrito correctamente.";
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Ocurrió un error al agregar el elemento al carrito.");
                // Log the exception (uncomment the line below if you have a logger configured)
                // _logger.LogError(ex, "Error al agregar elemento al carrito");
            }

            return RedirectToAction("Index");
        }


        [HttpPost]
        public async Task<IActionResult> EliminarDelCarrito(int id)
        {
            try
            {
                var item = await _context.CarroItems.FirstOrDefaultAsync(c => c.Id == id);

                if (item != null)
                {
                    _context.CarroItems.Remove(item);
                    await _context.SaveChangesAsync();
                    TempData["Message"] = "El elemento se eliminó del carrito correctamente.";
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Ocurrió un error al eliminar el elemento del carrito.");
                // Log the exception (uncomment the line below if you have a logger configured)
                // _logger.LogError(ex, "Error al eliminar elemento del carrito");
            }

            return RedirectToAction("Index");
        }
    }
}
