
from .base import SortStrategy

class HeapSort(SortStrategy):
    nombre = "Heap"
    def sort(self, a):
        a = a[:]
        def heapify(a, n, i):
            largest = i
            l, r = 2*i+1, 2*i+2
            if l < n and a[l][0] > a[largest][0]: largest = l
            if r < n and a[r][0] > a[largest][0]: largest = r
            if largest != i:
                a[i], a[largest] = a[largest], a[i]
                heapify(a, n, largest)
        n = len(a)
        for i in range(n//2 - 1, -1, -1):
            heapify(a, n, i)
        for i in range(n-1, 0, -1):
            a[i], a[0] = a[0], a[i]
            heapify(a, i, 0)
        return a
