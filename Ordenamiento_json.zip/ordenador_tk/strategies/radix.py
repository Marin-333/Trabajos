
from .base import SortStrategy

class RadixSort(SortStrategy):
    nombre = "Radix"
    def sort(self, a):
        if not a: return []
        vals = [int(round(x[0])) for x in a]
        mn = min(vals)
        shift = -mn if mn < 0 else 0
        pairs = [(v + shift, a[i][1]) for i, v in enumerate(vals)]
        base, exp = 10, 1
        maxv = max(v for v,_ in pairs)
        while maxv // exp > 0:
            buckets = [[] for _ in range(base)]
            for v, payload in pairs:
                buckets[(v // exp) % base].append((v, payload))
            pairs = [item for bucket in buckets for item in bucket]
            exp *= base
        return [((v - shift), payload) for v, payload in pairs]
