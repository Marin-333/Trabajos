
from .base import SortStrategy
from .bubble import BubbleSort
from .selection import SelectionSort
from .insertion import InsertionSort
from .merge import MergeSort
from .quick import QuickSort
from .counting import CountingSort
from .radix import RadixSort
from .bucket import BucketSort
from .heap_algo import HeapSort

ALGORITMOS_NUM = {
    "Burbuja": BubbleSort(),
    "Seleccion": SelectionSort(),
    "Insercion": InsertionSort(),
    "Merge": MergeSort(),
    "Quick": QuickSort(),
    "Counting": CountingSort(),
    "Radix": RadixSort(),
    "Bucket": BucketSort(),
    "Heap": HeapSort(),
}

ALGORITMOS_TEXTO = {
    "Burbuja": BubbleSort(),
    "Seleccion": SelectionSort(),
    "Insercion": InsertionSort(),
    "Merge": MergeSort(),
    "Quick": QuickSort(),
    "Heap": HeapSort(),
}
