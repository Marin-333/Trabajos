
import math
from .base import SortStrategy

class BucketSort(SortStrategy):
    nombre = "Bucket"
    def sort(self, a):
        if not a: return []
        vals = [x[0] for x in a]
        mn, mx = min(vals), max(vals)
        if mn == mx:
            return a[:]
        n = max(10, int(math.sqrt(len(a))))
        buckets = [[] for _ in range(n)]
        for pair in a:
            val = pair[0]
            idx = int((val - mn) / (mx - mn) * (n - 1))
            b = buckets[idx]
            inserted = False
            for i in range(len(b)):
                if pair[0] < b[i][0]:
                    b.insert(i, pair); inserted = True; break
            if not inserted:
                b.append(pair)
        out = []
        for b in buckets: out.extend(b)
        return out
