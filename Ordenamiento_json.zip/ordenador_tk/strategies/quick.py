
from .base import SortStrategy

class QuickSort(SortStrategy):
    nombre = "Quick"
    def sort(self, a):
        if len(a) <= 1: return a[:]
        pivot = a[len(a)//2][0]
        less  = [x for x in a if x[0] < pivot]
        equal = [x for x in a if x[0] == pivot]
        greater = [x for x in a if x[0] > pivot]
        return self.sort(less) + equal + self.sort(greater)
