
class SortStrategy:
    nombre = "Base"
    def sort(self, arr):
        raise NotImplementedError("Debe implementar sort(arr)")
