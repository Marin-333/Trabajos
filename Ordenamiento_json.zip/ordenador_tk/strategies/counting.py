
from .base import SortStrategy

class CountingSort(SortStrategy):
    nombre = "Counting"
    def sort(self, a):
        if not a: return []
        vals = [int(round(x[0])) for x in a]
        mn, mx = min(vals), max(vals)
        shift = -mn
        count = [0] * (mx - mn + 1)
        for v in vals:
            count[v + shift] += 1
        for i in range(1, len(count)):
            count[i] += count[i-1]
        out = [None] * len(a)
        for i in range(len(a)-1, -1, -1):
            v = vals[i]
            count[v + shift] -= 1
            out[count[v + shift]] = a[i]
        return out
