
from .base import SortStrategy

class BubbleSort(SortStrategy):
    nombre = "Burbuja"
    def sort(self, a):
        a = a[:]
        n = len(a)
        for i in range(n):
            swapped = False
            for j in range(0, n - i - 1):
                if a[j][0] > a[j+1][0]:
                    a[j], a[j+1] = a[j+1], a[j]
                    swapped = True
            if not swapped:
                break
        return a
