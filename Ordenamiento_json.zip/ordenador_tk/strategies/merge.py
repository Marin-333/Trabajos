
from .base import SortStrategy

class MergeSort(SortStrategy):
    nombre = "Merge"
    def sort(self, a):
        def merge(left, right):
            out, i, j = [], 0, 0
            while i < len(left) and j < len(right):
                if left[i][0] <= right[j][0]:
                    out.append(left[i]); i += 1
                else:
                    out.append(right[j]); j += 1
            out.extend(left[i:]); out.extend(right[j:])
            return out
        def msort(a):
            if len(a) <= 1: return a[:]
            mid = len(a)//2
            return merge(msort(a[:mid]), msort(a[mid:]))
        return msort(a)
