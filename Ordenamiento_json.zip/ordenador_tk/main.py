
from .data_loader import JSON_DATA, cargar_items_desde_json
from .app import App
from tkinter import messagebox

def main():
    try:
        items = cargar_items_desde_json(JSON_DATA)
    except ValueError as e:
        messagebox.showerror("JSON inválido", str(e))
        return
    app = App(items)
    app.mainloop()

if __name__ == "__main__":
    main()
