
import time
from typing import List, Tuple, Dict, Any
from .strategies import ALGORITMOS_NUM, ALGORITMOS_TEXTO

CAMPOS_NUMERICOS = ["elevation", "lat", "lon"]
CAMPOS_TEXTO = ["key", "name", "city", "state", "country", "tz"]

def tipo_de_campo(campo: str) -> str:
    return "numero" if campo in CAMPOS_NUMERICOS else "texto"

def preparar_pares(items: List[Dict[str, Any]], campo: str, tipo: str):
    pares = []
    if tipo == "numero":
        for it in items:
            val = it.get(campo, None)
            if val is None: continue
            try:
                num = float(val)
                pares.append((num, it))
            except:
                continue
    else:
        for it in items:
            s = it.get(campo, "")
            if s is None: s = ""
            s_norm = str(s).casefold()
            pares.append((s_norm, it))
    return pares

def aplicar_estrategia(pares, estrategia_nombre: str, descendente: bool, tipo: str):
    if tipo == "texto":
        estrategia = ALGORITMOS_TEXTO.get(estrategia_nombre)
        if estrategia is None:
            raise ValueError("Para texto usa: Burbuja, Seleccion, Insercion, Merge, Quick o Heap.")
    else:
        estrategia = ALGORITMOS_NUM.get(estrategia_nombre)
        if estrategia is None:
            raise ValueError("Algoritmo no soportado.")

    inicio = time.perf_counter()
    res = estrategia.sort(pares)
    dur = (time.perf_counter() - inicio) * 1000.0
    if descendente:
        res.reverse()
    return res, dur
