# Proyecto: Ordenador de JSON con Tkinter (POO2)

Este proyecto implementa una aplicación en **Python** usando **Tkinter** y el **Patrón Estrategia** para ordenar datos cargados desde un JSON embebido.

## 📂 Estructura del proyecto

```
ordenador_tk/
  ├── __init__.py
  ├── main.py
  ├── app.py
  ├── data_loader.py
  ├── utils.py
  └── strategies/
       ├── __init__.py
       ├── base.py
       ├── bubble.py
       ├── selection.py
       ├── insertion.py
       ├── merge.py
       ├── quick.py
       ├── counting.py
       ├── radix.py
       ├── bucket.py
       └── heap_algo.py
```

## 🚀 Cómo ejecutar

1. **Descomprimir el proyecto**
   Extrae `ordenador_tk_clean.zip` en una carpeta de tu preferencia.

2. **Abrir una terminal/consola**
   - En **Windows**: abre *PowerShell* o *cmd*.
   - En **Linux/Mac**: abre una terminal normal.

3. **Moverte a la carpeta donde está el proyecto**
   ```bash
   cd ruta/donde/descomprimiste
   ```

4. **Ejecutar el programa como módulo**
   - En **Windows**:
     ```bash
     py -m ordenador_tk.main
     ```
   - En **Linux/Mac**:
     ```bash
     python3 -m ordenador_tk.main
     ```

5. **Usar la interfaz gráfica**
   - Selecciona el **campo** a ordenar (texto o numérico).
   - Elige el **orden** (Ascendente o Descendente).
   - Escoge el **algoritmo de ordenamiento**.
   - Haz clic en **Ordenar**.

## 📌 Notas

- **Texto**: soporta Burbuja, Selección, Inserción, Merge, Quick, Heap.  
- **Numéricos**: soporta los 9 algoritmos (incluye Counting, Radix y Bucket).  
- El JSON está embebido en `data_loader.py` dentro de la variable `JSON_DATA`.  
  Si quieres usar otro JSON, reemplázalo allí.

---

✍️ Autor: *Proyecto académico POO2*
