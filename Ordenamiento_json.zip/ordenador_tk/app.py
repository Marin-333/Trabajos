
import tkinter as tk
from tkinter import ttk, messagebox
from .utils import CAMPOS_NUMERICOS, CAMPOS_TEXTO, tipo_de_campo, preparar_pares, aplicar_estrategia
from .strategies import ALGORITMOS_NUM, ALGORITMOS_TEXTO

class App(tk.Tk):
    def __init__(self, items):
        super().__init__()
        self.title("Ordenador de JSON - POO2 (Tkinter)")
        self.geometry("1100x660")
        self.minsize(980, 560)
        self.items = items

        frame_top = ttk.Frame(self, padding=10)
        frame_top.pack(side=tk.TOP, fill=tk.X)

        ttk.Label(frame_top, text="Campo:").grid(row=0, column=0, sticky="w")
        self.cmb_campo = ttk.Combobox(
            frame_top,
            values=CAMPOS_TEXTO + CAMPOS_NUMERICOS,
            state="readonly", width=18
        )
        self.cmb_campo.current(1)
        self.cmb_campo.grid(row=0, column=1, padx=6)

        ttk.Label(frame_top, text="Orden:").grid(row=0, column=2, sticky="w")
        self.cmb_orden = ttk.Combobox(
            frame_top,
            values=["Ascendente", "Descendente"],
            state="readonly", width=14
        )
        self.cmb_orden.current(0)
        self.cmb_orden.grid(row=0, column=3, padx=6)

        ttk.Label(frame_top, text="Algoritmo:").grid(row=0, column=4, sticky="w")
        self.cmb_alg = ttk.Combobox(frame_top, state="readonly", width=16)
        self.cmb_alg.grid(row=0, column=5, padx=6)

        self.btn_ordenar = ttk.Button(frame_top, text="Ordenar", command=self.ordenar)
        self.btn_ordenar.grid(row=0, column=6, padx=10)

        self.lbl_info = ttk.Label(frame_top, text="Listo.")
        self.lbl_info.grid(row=0, column=7, sticky="w", padx=10)

        self.cmb_campo.bind("<<ComboboxSelected>>", self._on_campo_cambia)
        self._on_campo_cambia()

        cols = ("key", "name", "city", "state", "country", "tz", "elevation", "lat", "lon")
        self.tree = ttk.Treeview(self, columns=cols, show="headings")
        for c in cols:
            self.tree.heading(c, text=c)
            width = 130
            if c in ("key","state","country","tz"): width = 110
            if c in ("elevation","lat","lon"): width = 100
            if c == "name": width = 220
            self.tree.column(c, width=width, anchor="w")
        self.tree.pack(expand=True, fill=tk.BOTH, padx=10, pady=(0,10))

        self._cargar_tabla(self.items)

        style = ttk.Style(self)
        try: style.theme_use("clam")
        except: pass

    def _on_campo_cambia(self, event=None):
        campo = self.cmb_campo.get()
        tipo = tipo_de_campo(campo)
        if tipo == "texto":
            self.cmb_alg["values"] = list(ALGORITMOS_TEXTO.keys())
            self.cmb_alg.current(list(ALGORITMOS_TEXTO.keys()).index("Quick"))
        else:
            self.cmb_alg["values"] = list(ALGORITMOS_NUM.keys())
            self.cmb_alg.current(list(ALGORITMOS_NUM.keys()).index("Quick"))

    def _cargar_tabla(self, items):
        self.tree.delete(*self.tree.get_children())
        for it in items:
            self.tree.insert("", tk.END, values=(
                it.get("key",""),
                it.get("name",""),
                it.get("city",""),
                it.get("state",""),
                it.get("country",""),
                it.get("tz",""),
                it.get("elevation",""),
                it.get("lat",""),
                it.get("lon",""),
            ))

    def ordenar(self):
        campo = self.cmb_campo.get()
        orden_txt = self.cmb_orden.get()
        algoritmo = self.cmb_alg.get()
        descendente = (orden_txt == "Descendente")

        tipo = tipo_de_campo(campo)
        pares = preparar_pares(self.items, campo, tipo)
        if not pares:
            messagebox.showwarning("Aviso", f"No hay datos en el campo '{campo}'.")
            return

        try:
            res, dur_ms = aplicar_estrategia(pares, algoritmo, descendente, tipo)
        except ValueError as e:
            messagebox.showwarning("Aviso", str(e))
            return
        except Exception as e:
            messagebox.showerror("Error", f"Ocurrió un error al ordenar: {e}")
            return

        ordenados = [item for _, item in res]
        self._cargar_tabla(ordenados)
        self.lbl_info.config(
            text=f"{'Desc' if descendente else 'Asc'} por '{campo}' con {algoritmo} en {dur_ms:.2f} ms (n={len(ordenados)})"
        )
