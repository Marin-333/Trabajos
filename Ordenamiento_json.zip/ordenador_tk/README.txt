
Proyecto: Ordenador de JSON (Tkinter, POO2)
==========================================

Estructura:
- ordenador_tk/
  - __init__.py
  - main.py
  - app.py
  - data_loader.py   (aquí está el JSON integrado en JSON_DATA)
  - utils.py
  - strategies/
      - __init__.py
      - base.py
      - bubble.py
      - selection.py
      - insertion.py
      - merge.py
      - quick.py
      - counting.py
      - radix.py
      - bucket.py
      - heap_algo.py

Cómo ejecutar
-------------
1) Asegúrate de tener Python 3.
2) Desde la carpeta superior a "ordenador_tk", ejecuta:
   - Windows:    py -m ordenador_tk.main
   - Linux/Mac:  python3 -m ordenador_tk.main

También puedes ejecutar creando un pequeño launcher "run.py":
    from ordenador_tk.main import main
    if __name__ == "__main__":
        main()

Notas
-----
- Para ordenar texto: Burbuja, Selección, Inserción, Merge, Quick, Heap.
- Para números: todos los 9 algoritmos (Counting, Radix, Bucket incluidos).
- Descendente/Ascendente: se controla desde la UI (se invierte el resultado si es descendente).
- El JSON ya está embebido en data_loader.JSON_DATA. Si quieres reemplazarlo, pega tu JSON allí.
