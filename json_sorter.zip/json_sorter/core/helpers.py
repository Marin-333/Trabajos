
# -*- coding: utf-8 -*-
from typing import Any, List, Tuple, Dict
import json, sys, os

def to_comparable(v: Any):
    """Convierte valores a algo comparable de forma robusta para algoritmos comparativos."""
    if v is None:
        return ""
    if isinstance(v, (int, float)):
        return v
    return str(v).casefold()

def is_all_int_nonneg(values: List[Any]) -> Tuple[bool, int, int]:
    """Verifica si todos son enteros >= 0 y retorna (ok, minv, maxv)."""
    try:
        ints = [int(v) for v in values]
        if any(i < 0 for i in ints):
            return (False, 0, 0)
        return (True, min(ints), max(ints))
    except Exception:
        return (False, 0, 0)

def is_all_int(values: List[Any]) -> bool:
    try:
        _ = [int(v) for v in values]
        return True
    except Exception:
        return False

def is_all_numeric(values: List[Any]) -> bool:
    try:
        _ = [float(v) for v in values]
        return True
    except Exception:
        return False

def read_json_file(path: str):
    """Lee y parsea JSON. Lanza ValueError con mensajes claros."""
    if not os.path.exists(path):
        raise ValueError(f"No se encontró el archivo: {path}")
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        raise ValueError(f"El archivo no es un JSON válido: {e}")
    except Exception as e:
        raise ValueError(f"No se pudo leer el archivo: {e}")

def normalize_items(data) -> List[Dict]:
    """Convierte el JSON en una lista de registros (dict)."""
    if isinstance(data, dict):
        items = []
        for k, v in data.items():
            if isinstance(v, dict):
                rec = {"__key__": k, **v}
            else:
                rec = {"__key__": k, "value": v}
            items.append(rec)
        return items
    elif isinstance(data, list):
        # Si no son dict, envolverlos
        out = []
        for idx, v in enumerate(data):
            if isinstance(v, dict):
                out.append(v)
            else:
                out.append({"__index__": idx, "value": v})
        return out
    else:
        raise ValueError("Formato JSON no soportado (debe ser objeto o lista).")

def detect_fields(items: List[Dict], sample: int = 50) -> List[str]:
    fields = set()
    for rec in items[: min(sample, len(items))]:
        if isinstance(rec, dict):
            fields.update(rec.keys())
    return sorted(fields)

def safe_preview(items, n=10) -> str:
    from json import dumps
    lines = []
    for i, rec in enumerate(items[:n], 1):
        frag = dumps(rec, ensure_ascii=False)
        if len(frag) > 300:
            frag = frag[:300] + "..."
        lines.append(f"{i:>3}: {frag}")
    return "\n".join(lines)

def choose(prompt: str, options: List[str]) -> str:
    print(prompt)
    for i, opt in enumerate(options, 1):
        print(f"  {i}. {opt}")
    while True:
        sel = input("> ").strip().lower()
        if sel.isdigit():
            idx = int(sel)
            if 1 <= idx <= len(options):
                return options[idx - 1]
        if sel in options:
            return sel
        print("Opción inválida. Intenta de nuevo.")
