
# -*- coding: utf-8 -*-
import argparse
from typing import Dict, Any, Callable
from core.helpers import (
    read_json_file, normalize_items, detect_fields, to_comparable,
    is_all_int_nonneg, is_all_int, is_all_numeric, safe_preview, choose
)
from algorithms import ALGORITHMS
from algorithms import bucket as bucket_sort  # para pasar buckets_count

BANNER = """
==============================================
   JSON Sorter • Menú Interactivo
==============================================
"""

def build_parser():
    p = argparse.ArgumentParser(
        description="Ordena un JSON por un campo con múltiples algoritmos."
    )
    # ruta ahora opcional: si no viene, se pide por input
    p.add_argument("ruta", nargs="?", help="Ruta al archivo JSON (.json o .txt con JSON).")
    p.add_argument("--interactivo", action="store_true",
                   help="Forzar modo interactivo de selección de ruta/campo/método/orden.")
    p.add_argument("--campo", help="Campo por el que ordenar.")
    p.add_argument("--metodo", choices=list(ALGORITHMS.keys()), help="Algoritmo a usar.")
    p.add_argument("--orden", choices=["asc", "desc"], default="asc", help="Orden.")
    p.add_argument("--salida", help="Ruta del archivo de salida (.json).")
    p.add_argument("--preview", type=int, default=10, help="Cantidad de filas de vista previa.")
    p.add_argument("--buckets", type=int, default=10, help="Número de cubetas para bucket sort.")
    return p

def pick_route_if_needed(args) -> str:
    if args.ruta:
        return args.ruta
    print(BANNER)
    print("No se proporcionó ruta. Ingresa la ruta del archivo JSON (o arrástralo aquí):")
    try:
        ruta = input("> ").strip().strip('"')
    except KeyboardInterrupt:
        print("\n[Info] Operación cancelada por el usuario.")
        raise SystemExit(1)
    if not ruta:
        print("[Error] Debe proporcionar una ruta de archivo.")
        raise SystemExit(1)
    return ruta

def interactive_flow(items, fields, args):
    print(BANNER)
    print("Campos detectados:\n  " + ", ".join(fields) + "\n")
    campo = args.campo or choose("Elige el CAMPO por el que quieres ordenar:", fields)

    algos = list(ALGORITHMS.keys())
    metodo = args.metodo or choose("Elige el MÉTODO de ordenamiento:", algos)

    orden = args.orden if args.orden in ("asc", "desc") else choose("Elige el ORDEN:", ["asc", "desc"])
    reverse = (orden == "desc")

    # --- Validaciones especiales y selección de key adecuada ---
    raw_vals = [rec.get(campo, None) for rec in items]

    try:
        if metodo in ("counting", "radix", "bucket"):
            if metodo == "counting":
                ok, _, _ = is_all_int_nonneg(raw_vals)
                if not ok:
                    raise ValueError("Counting sort requiere que el campo sea entero >= 0.")
                keyfunc = lambda rec: int(rec.get(campo, 0))
                sorter = ALGORITHMS[metodo]
                items_sorted = sorter(items, key=keyfunc, reverse=reverse)

            elif metodo == "radix":
                if not is_all_int(raw_vals):
                    raise ValueError("Radix sort requiere que el campo sea entero (puede haber negativos).")
                keyfunc = lambda rec: int(rec.get(campo, 0))
                sorter = ALGORITHMS[metodo]
                items_sorted = sorter(items, key=keyfunc, reverse=reverse)

            elif metodo == "bucket":
                if not is_all_numeric(raw_vals):
                    raise ValueError("Bucket sort requiere que el campo sea numérico (int/float).")
                keyfunc = lambda rec: float(rec.get(campo, 0.0))
                items_sorted = bucket_sort(items, key=keyfunc, reverse=reverse, buckets_count=max(2, args.buckets))
        else:
            sorter = ALGORITHMS[metodo]
            key_comp = lambda rec: to_comparable(rec.get(campo, ""))
            items_sorted = sorter(items, key=key_comp, reverse=reverse)

    except ValueError as e:
        print(f"\n[Aviso] {e}")
        print("Sugerencia: usa un algoritmo comparativo como 'merge', 'quick', 'heap', 'insercion', 'seleccion' o 'burbuja'.")
        return None, None, None

    return items_sorted, campo, metodo

def main():
    parser = build_parser()
    args = parser.parse_args()

    ruta = pick_route_if_needed(args)

    try:
        data = read_json_file(ruta)
        items = normalize_items(data)
    except ValueError as e:
        print(f"[Error] {e}")
        return 1
    except Exception as e:
        print(f"[Error inesperado] {e}")
        return 1

    if not items:
        print("No hay elementos para ordenar.")
        return 0

    fields = detect_fields(items)
    if not fields:
        print("No se detectaron campos para ordenar.")
        return 1

    # Si el usuario pasó todo por flags y no forzó interactivo, usamos directo.
    non_interactive = (args.campo and args.metodo) and (not args.interactivo)
    if non_interactive:
        # Replicamos la ruta no interactiva anterior
        campo = args.campo
        if campo not in fields:
            print(f"[Error] El campo '{campo}' no existe. Campos disponibles: {', '.join(fields)}")
            return 1
        metodo = args.metodo
        reverse = (args.orden == "desc")
        raw_vals = [rec.get(campo, None) for rec in items]
        try:
            if metodo in ("counting", "radix", "bucket"):
                if metodo == "counting":
                    ok, _, _ = is_all_int_nonneg(raw_vals)
                    if not ok:
                        raise ValueError("Counting sort requiere que el campo sea entero >= 0.")
                    keyfunc = lambda rec: int(rec.get(campo, 0))
                    sorter = ALGORITHMS[metodo]
                    items_sorted = sorter(items, key=keyfunc, reverse=reverse)
                elif metodo == "radix":
                    if not is_all_int(raw_vals):
                        raise ValueError("Radix sort requiere que el campo sea entero (puede haber negativos).")
                    keyfunc = lambda rec: int(rec.get(campo, 0))
                    sorter = ALGORITHMS[metodo]
                    items_sorted = sorter(items, key=keyfunc, reverse=reverse)
                elif metodo == "bucket":
                    if not is_all_numeric(raw_vals):
                        raise ValueError("Bucket sort requiere que el campo sea numérico (int/float).")
                    keyfunc = lambda rec: float(rec.get(campo, 0.0))
                    items_sorted = bucket_sort(items, key=keyfunc, reverse=reverse, buckets_count=max(2, args.buckets))
            else:
                sorter = ALGORITHMS[metodo]
                key_comp = lambda rec: to_comparable(rec.get(campo, ""))
                items_sorted = sorter(items, key=key_comp, reverse=reverse)
        except ValueError as e:
            print(f"[Aviso] {e}")
            print("Sugerencia: usa un algoritmo comparativo como 'merge', 'quick', 'heap', 'insercion', 'seleccion' o 'burbuja'.")
            return 1
    else:
        # Menú interactivo
        while True:
            result = interactive_flow(items, fields, args)
            if result == (None, None, None):
                # Si el algoritmo elegido no aplica, repetir menú
                print("\nIntenta nuevamente con otro campo o método.\n")
                continue
            items_sorted, campo, metodo = result
            break

    # Mostrar preview y preguntar por guardado
    reverse = (args.orden == "desc")
    print(f"\nOrdenado por '{campo}' usando '{metodo}' en orden {'desc' if reverse else 'asc'}.")
    print("\nPreview:")
    print(safe_preview(items_sorted, n=max(1, args.preview)))

    # Decidir guardar
    salida = args.salida
    if not salida:
        print("\n¿Deseas guardar el resultado en un archivo .json?")
        opc = choose("Elige una opción:", ["sí", "no"])
        if opc == "sí":
            print("Ingresa la ruta de salida (ej: ordenado.json):")
            salida = input("> ").strip().strip('"')

    if salida:
        try:
            import json
            with open(salida, "w", encoding="utf-8") as f:
                json.dump(items_sorted, f, ensure_ascii=False, indent=2)
            print(f"\nResultado guardado en: {salida}")
        except Exception as e:
            print(f"[Error] No se pudo guardar el archivo de salida: {e}")
            return 1

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
