# 📝 Instrucciones de ejecución - JSON Sorter

Este proyecto permite **ordenar registros en un archivo JSON** usando distintos algoritmos de ordenamiento.  
A continuación, se explica **cómo ejecutarlo paso a paso**.

---

## 1️⃣ Requisitos previos
- Tener instalado **Python 3.8 o superior**.
- Descomprimir la carpeta `json_sorter` en tu equipo.
- Ubicar tu archivo JSON (por ejemplo `airports.txt` o `airports.json`) en la carpeta **Descargas** o junto a `app.py`.

---

## 2️⃣ Ejecución en modo interactivo
Este es el modo recomendado para uso fácil.

1. Abre una terminal dentro de la carpeta `json_sorter`.
2. Ejecuta el programa indicando la ruta del archivo JSON:

```bash
python app.py "..\airports.txt"
```

- Si no indicas la ruta, el programa te la pedirá en pantalla.
- Luego aparecerá un **menú interactivo** para elegir:
  1. Campo por el que ordenar.
  2. Método de ordenamiento (burbuja, selección, inserción, merge, quick, counting, radix, bucket, heap).
  3. Orden ascendente o descendente.
- El programa mostrará un **preview** de los primeros registros y te preguntará si deseas **guardar el resultado en un archivo `.json`**.

---

## 3️⃣ Ejecución directa (sin menú)
Si ya sabes lo que quieres, puedes pasar las opciones como argumentos:

```bash
python app.py "..\airports.txt" --metodo quick --campo name --orden asc --salida "..\ordenado.json"
```

### Parámetros disponibles
- `ruta`: ruta del archivo JSON.
- `--campo`: campo del JSON por el que ordenar (ej: `name`, `city`, `lat`).
- `--metodo`: algoritmo (`burbuja`, `seleccion`, `insercion`, `merge`, `quick`, `counting`, `radix`, `bucket`, `heap`).
- `--orden`: `asc` (ascendente, por defecto) o `desc` (descendente).
- `--salida`: archivo `.json` donde guardar el resultado ordenado.
- `--preview`: número de filas a mostrar en consola (por defecto 10).
- `--buckets`: número de cubetas (solo para bucket sort, por defecto 10).
- `--interactivo`: fuerza el menú interactivo incluso si pasas opciones.

---

## 4️⃣ Recomendaciones
- Usa **merge**, **quick** o **heap** para archivos grandes (son rápidos).
- Evita **burbuja**, **selección** e **inserción** en JSON grandes (son lentos).
- `counting`: solo para enteros ≥ 0 y con rango pequeño.
- `radix`: solo para enteros (positivos o negativos).
- `bucket`: solo para números (int/float).

---

✅ Con esto puedes ejecutar el programa fácilmente y elegir cómo ordenar tus datos JSON.
