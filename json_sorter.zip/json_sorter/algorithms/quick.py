
# -*- coding: utf-8 -*-
def sort(arr, key, reverse=False):
    a = arr[:]
    def _qs(lo, hi):
        if lo >= hi: return
        pivot = key(a[(lo + hi)//2])
        i, j = lo, hi
        while i <= j:
            while ((key(a[i]) < pivot) ^ reverse): i += 1
            while ((key(a[j]) > pivot) ^ reverse): j -= 1
            if i <= j:
                a[i], a[j] = a[j], a[i]
                i += 1; j -= 1
        _qs(lo, j); _qs(i, hi)
    _qs(0, len(a) - 1)
    return a
