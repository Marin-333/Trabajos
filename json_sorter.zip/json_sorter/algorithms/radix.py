
# -*- coding: utf-8 -*-
from core.helpers import is_all_int

def sort(arr, key, reverse=False):
    keys = [key(x) for x in arr]
    if not is_all_int(keys):
        raise ValueError("Radix sort requiere enteros (positivos/negativos).")
    pairs = list(zip(keys, arr))
    neg = [(k, v) for (k, v) in pairs if k < 0]
    pos = [(k, v) for (k, v) in pairs if k >= 0]

    def _radix(items):
        if not items: return items
        maxv = max(abs(k) for k, _ in items)
        exp = 1
        out = items[:]
        while maxv // exp > 0:
            buckets = [[] for _ in range(10)]
            for k, v in out:
                digit = (abs(k) // exp) % 10
                buckets[digit].append((k, v))
            out = [kv for b in buckets for kv in b]
            exp *= 10
        return out

    neg_sorted = _radix(neg)
    pos_sorted = _radix(pos)

    neg_sorted.sort(key=lambda kv: kv[0])
    pos_sorted.sort(key=lambda kv: kv[0])

    merged = [v for _, v in neg_sorted] + [v for _, v in pos_sorted]
    if reverse:
        merged.reverse()
    return merged
