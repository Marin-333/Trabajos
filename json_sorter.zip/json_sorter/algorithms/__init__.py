
# -*- coding: utf-8 -*-
from .bubble import sort as burbuja
from .selection import sort as seleccion
from .insertion import sort as insercion
from .merge import sort as merge
from .quick import sort as quick
from .counting import sort as counting
from .radix import sort as radix
from .bucket import sort as bucket
from .heap import sort as heap

ALGORITHMS = {
    "burbuja": burbuja,
    "seleccion": seleccion,
    "insercion": insercion,
    "merge": merge,
    "quick": quick,
    "counting": counting,
    "radix": radix,
    "bucket": bucket,
    "heap": heap,
}
