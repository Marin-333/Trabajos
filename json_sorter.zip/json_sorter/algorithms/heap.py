
# -*- coding: utf-8 -*-
def sort(arr, key, reverse=False):
    a = arr[:]
    def cmp(i, j):
        return (key(a[i]) > key(a[j])) ^ reverse
    def heapify(n, i):
        top = i
        l, r = 2*i + 1, 2*i + 2
        if l < n and cmp(l, top): top = l
        if r < n and cmp(r, top): top = r
        if top != i:
            a[i], a[top] = a[top], a[i]
            heapify(n, top)
    n = len(a)
    for i in range(n//2 - 1, -1, -1):
        heapify(n, i)
    for end in range(n - 1, 0, -1):
        a[0], a[end] = a[end], a[0]
        heapify(end, 0)
    return a
