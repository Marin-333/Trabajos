
# -*- coding: utf-8 -*-
def sort(arr, key, reverse=False):
    def merge(left, right):
        out = []
        i = j = 0
        while i < len(left) and j < len(right):
            cond = (key(left[i]) <= key(right[j])) ^ reverse
            if cond:
                out.append(left[i]); i += 1
            else:
                out.append(right[j]); j += 1
        out.extend(left[i:]); out.extend(right[j:])
        return out

    def _ms(a):
        if len(a) <= 1:
            return a
        mid = len(a) // 2
        return merge(_ms(a[:mid]), _ms(a[mid:]))
    return _ms(arr[:])
