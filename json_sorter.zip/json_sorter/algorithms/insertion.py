
# -*- coding: utf-8 -*-
def sort(arr, key, reverse=False):
    a = arr[:]
    for i in range(1, len(a)):
        curr = a[i]
        j = i - 1
        while j >= 0 and ((key(a[j]) > key(curr)) ^ reverse):
            a[j + 1] = a[j]
            j -= 1
        a[j + 1] = curr
    return a
