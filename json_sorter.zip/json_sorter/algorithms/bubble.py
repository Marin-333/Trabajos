
# -*- coding: utf-8 -*-
def sort(arr, key, reverse=False):
    a = arr[:]
    n = len(a)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if (key(a[j]) > key(a[j + 1])) ^ reverse:
                a[j], a[j + 1] = a[j + 1], a[j]
                swapped = True
        if not swapped:
            break
    return a
