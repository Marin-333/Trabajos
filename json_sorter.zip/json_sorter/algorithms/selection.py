
# -*- coding: utf-8 -*-
def sort(arr, key, reverse=False):
    a = arr[:]
    n = len(a)
    for i in range(n):
        idx_ext = i
        for j in range(i + 1, n):
            better = (key(a[j]) < key(a[idx_ext])) ^ reverse
            if better:
                idx_ext = j
        a[i], a[idx_ext] = a[idx_ext], a[i]
    return a
