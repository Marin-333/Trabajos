
# -*- coding: utf-8 -*-
from core.helpers import is_all_numeric
from .insertion import sort as insertion_sort

def sort(arr, key, reverse=False, buckets_count=10):
    vals = [key(x) for x in arr]
    if not is_all_numeric(vals):
        raise ValueError("Bucket sort requiere valores numéricos.")
    vals = [float(v) for v in vals]
    mn, mx = min(vals), max(vals)
    if mx == mn:
        res = arr[:]
        if reverse: res.reverse()
        return res
    buckets = [[] for _ in range(buckets_count)]
    for item, val in zip(arr, vals):
        idx = int((val - mn) / (mx - mn + 1e-12) * (buckets_count - 1))
        buckets[idx].append(item)
    res = []
    for b in buckets:
        res.extend(insertion_sort(b, key=key, reverse=False))
    if reverse:
        res.reverse()
    return res
