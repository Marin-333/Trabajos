
# -*- coding: utf-8 -*-
from core.helpers import is_all_int_nonneg

def sort(arr, key, reverse=False):
    keys = [key(x) for x in arr]
    ok, mn, mx = is_all_int_nonneg(keys)
    if not ok:
        raise ValueError("Counting sort requiere enteros >= 0.")
    rng = mx - mn + 1
    if rng > 1_000_000:
        raise ValueError(f"Rango demasiado grande para counting sort ({rng}).")
    count = [0] * rng
    for k in keys:
        count[k - mn] += 1
    for i in range(1, rng):
        count[i] += count[i - 1]
    out = [None] * len(arr)
    for i in range(len(arr) - 1, -1, -1):
        k = keys[i] - mn
        count[k] -= 1
        out[count[k]] = arr[i]
    if reverse:
        out.reverse()
    return out
